/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle.Connexion;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import Entite.Parametres;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author a.catty
 */
public abstract class ControleConnexion {
    static Parametres lesParametres;
    static boolean etatConnexion;
    static Connection laConnectionStatique;
    
    static{
        boolean ok = true;
        lesParametres = new Parametres();
        try {
            Class.forName(lesParametres.getDriverSGBD());
            etatConnexion = true;
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Classe non Trouvée pour le chargement du pilote JDBC MYSQL","ALERTE",JOptionPane.ERROR_MESSAGE);
            ok = false;
            etatConnexion = false;
        }
        // Etablir la connexion avec la BDD
        if(ok){
            try{
                String urlDB = lesParametres.getServeurBD();
                String nomUtil = lesParametres.getNomUtilisateur();
                String MDP = lesParametres.getMotDePasse();
                
                laConnectionStatique = (Connection) DriverManager.getConnection(urlDB, nomUtil, MDP);
                etatConnexion = true;
            } catch (Exception e){
                JOptionPane.showMessageDialog(null,"Impossible de se connecter à la base de données", "ALERTE", JOptionPane.ERROR_MESSAGE);
                etatConnexion = false;
            }
        }
    }

    public static Parametres getLesParametres() {
        return lesParametres;
    }

    public static boolean isEtatConnexion() {
        return etatConnexion;
    }

    public static Connection getLaConnectionStatique() {
        return laConnectionStatique;
    }
    
    public static boolean control(String nom, String mdp) {
        boolean verification;
        
        if(nom.equals(lesParametres.getNomGestionnaire())&&mdp.equals(lesParametres.getMotDePasseGestionnaire())){
            verification = etatConnexion;
        } else {
            JOptionPane.showMessageDialog(null, "Erreur de Saisie", "Erreur", JOptionPane.ERROR_MESSAGE);
            verification = false;
        }
        return verification;
    }
    
    public static void fermetureSession(){
        try {
            laConnectionStatique.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Problème rencontré à la fermeture de la connection", "ERREUR", JOptionPane.ERROR_MESSAGE);
        }
    }
}
