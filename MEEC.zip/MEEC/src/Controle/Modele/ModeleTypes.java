/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle.Modele;

import Entite.Conteneur;
import Entite.TypeCont;
import Entite.TypeEmplacement;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author arthu
 */
public class ModeleTypes extends AbstractTableModel {
    TypeCont unType;
    private ArrayList<TypeCont> lesDonnes;
    private final String[] lesTitres={"Id","Type de Conteneur"};
    
    public ModeleTypes (){
        this.unType = new TypeCont();
        this.lesDonnes = unType.getLesEnrg();
    }
    
    @Override
    public int getRowCount() {
        return lesDonnes.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
    @Override
    public String getColumnName(int columnIndex){
        return lesTitres[columnIndex];
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 1 -> String.class;
            case 2 -> String.class;
            default -> Object.class;
        };
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       return switch (columnIndex){
           case 0 -> lesDonnes.get(rowIndex).getNumType();
           case 1 -> lesDonnes.get(rowIndex).getNomType();
           default -> null;
       };
    }
}
