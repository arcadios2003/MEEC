/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle.Modele;

import Entite.Conteneur;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author arthu
 */
public class ModeleConteneur extends AbstractTableModel{
    Conteneur unConteneur;
    private ArrayList<Conteneur> lesDonnes;
    private final String[] lesTitres={"N° Conteneur","Quai","Allee","Emplacement","Etage","Client"};
    
    public ModeleConteneur (){
        this.unConteneur = new Conteneur();
        this.lesDonnes = unConteneur.getLesEnrg();
    }
    
    
    @Override
    public int getRowCount() {
        return lesDonnes.size();
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }
    
 /*   @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0 : return lesDonnes.get(rowIndex).getIdConteneur();
            case 1 : return lesDonnes.get(rowIndex).getQuai();
            case 2 : return lesDonnes.get(rowIndex).getAllee();
            case 3 : return lesDonnes.get(rowIndex).getEmplacement();
            case 4 : return lesDonnes.get(rowIndex).getLoueur();
            default: return null;
        }
    }*/
    
    @Override
    public String getColumnName(int columnIndex){
        return lesTitres[columnIndex];
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 1 -> String.class;
            case 2 -> String.class;
            case 3 -> String.class;
            case 4 -> String.class;
            case 5 -> String.class;
            default -> Object.class;
        };
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
       return switch (columnIndex){
           case 0 -> lesDonnes.get(rowIndex).getIdConteneur();
           case 1 -> lesDonnes.get(rowIndex).getQuai();
           case 2 -> lesDonnes.get(rowIndex).getAllee();
           case 3 -> lesDonnes.get(rowIndex).getEmplacement();
           case 4 -> lesDonnes.get(rowIndex).getEtage();
           case 5 -> lesDonnes.get(rowIndex).getLoueur();
           default -> null;
       };
    }
}
