/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle.Modele;

import Entite.Position;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author a.catty
 */
public class ModeleVoid extends AbstractTableModel{
    Position instanceConteneurPhysique;
    private ArrayList<Position> lesDonnes;
    private final String[] lesTitres={"Etage","N° Conteneur"};
    
    @Override
    public int getRowCount() {
        return 0;
    }

    @Override
    public int getColumnCount() {
        return lesTitres.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0 : return lesDonnes.get(rowIndex).getEtage();
            case 1 : return lesDonnes.get(rowIndex).getNumConteneur();
            default: return null;
        }
    }
    
    @Override
    public String getColumnName(int columnIndex){
        return lesTitres[columnIndex];
    }
}
