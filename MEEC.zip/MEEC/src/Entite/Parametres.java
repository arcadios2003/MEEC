/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

/**
 *
 * @author a.catty
 */
public class Parametres {
    private String nomUtilisateur;
    private String motDePasse;
    private String serveurBD;
    private String driverSGBD;
    private String nomGestionnaire;
    private String motDePasseGestionnaire;

    public String getNomUtilisateur() {
        return nomUtilisateur;
    }

    public void setNomUtilisateur(String nomUtilisateur) {
        this.nomUtilisateur = nomUtilisateur;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public String getServeurBD() {
        return serveurBD;
    }

    public void setServeurBD(String serveurBD) {
        this.serveurBD = serveurBD;
    }

    public String getDriverSGBD() {
        return driverSGBD;
    }

    public void setDriverSGBD(String driverSGBD) {
        this.driverSGBD = driverSGBD;
    }

    public String getNomGestionnaire() {
        return nomGestionnaire;
    }

    public void setNomGestionnaire(String nomGestionnaire) {
        this.nomGestionnaire = nomGestionnaire;
    }

    public String getMotDePasseGestionnaire() {
        return motDePasseGestionnaire;
    }

    public void setMotDePasseGestionnaire(String motDePasseGestionnaire) {
        this.motDePasseGestionnaire = motDePasseGestionnaire;
    }
    
    public Parametres () {
        nomUtilisateur = "root";
        motDePasse = "";
        driverSGBD = "org.gjt.mm.mysql.Driver";
        serveurBD = "jdbc:mysql://localhost/tholdiport";
        nomGestionnaire = "Gestionnaire";
        motDePasseGestionnaire = "azerty";
    }
}
