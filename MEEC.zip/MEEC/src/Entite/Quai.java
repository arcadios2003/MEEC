/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;
import java.util.ArrayList;
import java.sql.Connection;
import Controle.Connexion.ControleConnexion;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 *
 * @author a.catty
 */
public class Quai {
    String numQuai;
    private final ArrayList<Quai> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();

    public Quai(String numQuai){
        this.numQuai=numQuai;
    }
    
    public Quai(){
        lireRecup();
    }

    public ArrayList<Quai> getLesEnrg() {
        return lesEnrg;
    }
    
    public void creer(String numId){
        try { 
           String requete = null;
            requete="INSERT INTO quai VALUES (?)";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            prepare.setString(1,numId);
            prepare.execute();
            prepare.close();
            JOptionPane.showMessageDialog(null, "Le Quai a été créé", "Information", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Ajout non effectuée: " + ex.getMessage(),"PROBLEME",JOptionPane.ERROR_MESSAGE);
        }      
    }
    
    private void lireRecup(){
        String rqSQL = "SELECT * FROM quai";
        lesEnrg.retainAll(lesEnrg);
        
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()) {
                String unId= rs.getString("numquai");
                lesEnrg.add(new Quai(unId));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Quai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void supprimer (String Id){
        String requete = null;
        try{
            Allee uneAllee = new Allee(Id);
            if(uneAllee.getLesEnrg().size()==0){
                requete = "DELETE FROM quai WHERE numquai = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(requete);
                prepare.setString(1,Id);
                JOptionPane.showMessageDialog(null, "Le quai a été supprimer", "Information", JOptionPane.INFORMATION_MESSAGE);
                prepare.executeUpdate();
                prepare.close();
            } else {
                JOptionPane.showMessageDialog(null, "Le Quai ne peut être supprimer","ALERTE",JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Suppresion non effecutée :" + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public String getNumQuai() {
        return numQuai;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }
}

