/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

/**
 *
 * @author a.catty
 */
public class Emplacement {
    String numEmplacement;
    String numAllee;
    String numQuai;
    private final ArrayList<Emplacement> lesEnrg = new ArrayList<>();
    
    public ArrayList<Emplacement> getLesEnrg() {
        return lesEnrg;
    }
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();

    public Emplacement(String numEmplacement,String numAllee, String numQuai){
        this.numEmplacement = numEmplacement;
        this.numAllee = numAllee;
        this.numQuai = numQuai;
    }
    
    public Emplacement(){
        lireRecup("","");
    }
    
    public Emplacement(String Allee,String quai){
        lireRecup(Allee,quai);
    }
    
    public Emplacement(String quai){
        lireRecup("",quai);
    }
    
    public String getNumEmplacement() {
        return numEmplacement;
    }
    
    public void lireRecup(String Allee,String quai) {
        if(quai.equals("")){
            quai="%";
        }
        if (Allee.equals("")){
            Allee="%";
        }
        String rqSQL="SELECT * FROM emplacement WHERE numAllee LIKE '" + Allee + "' AND numQuai LIKE '" + quai + "' order by numQuai, numAllee, numEmplacement";
        lesEnrg.retainAll(lesEnrg);
        
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()){
                String unIdquai = rs.getString("numquai");
                String unIdAllee = rs.getString("numallee");
                String unIdEmplacement = rs.getString("numemplacement");
                lesEnrg.add(new Emplacement(unIdEmplacement,unIdAllee, unIdquai));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erreur" 
             + ex.getMessage(),"ALERTE",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void creer (String numEmplacement,String numAllee, String numQuai){
        boolean ok = true;
        Position unePosition = new Position();
        if (!lesEnrg.isEmpty()){
            ok = false;
            int i;
            i = -1;
            do {
                i++;
            } while (!lesEnrg.get(i).numQuai.equals(numQuai)&& !lesEnrg.get(i).numAllee.equals(numAllee)&& !lesEnrg.get(i).numEmplacement.equals(numEmplacement)&& i<lesEnrg.size());
            if(lesEnrg.get(i).numQuai.equals(numQuai)&&lesEnrg.get(i).numAllee.equals(numAllee) &&lesEnrg.get(i).numEmplacement.equals(numEmplacement)){
                JOptionPane.showMessageDialog(null, "Ajout non effectué :"
                    + "l'emplacement existe déjà!", "PROBLEME", JOptionPane.ERROR_MESSAGE);
            } else {
                ok = true;
            }
        }
        if(ok){
            String requete = null;
            try{
                requete = "INSERT INTO emplacement VALUE (?,?,?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);
                prepare.setString(1,numEmplacement);
                prepare.setString(2,numAllee);
                prepare.setString(3,numQuai);
                prepare.execute();
                prepare.close();
                int i;
                for (i=0; i<=3; i++){
                    unePosition.creer(numEmplacement, numAllee, numQuai, String.valueOf(i));
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                        + ex.getMessage(),"Probleme",JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void supprimer (String numEmplacement, String numAllee, String numQuai){
        String requete = null;
        int i;
        try {
            Position unePos = new Position(numEmplacement,numAllee,numQuai,false);
            if(unePos.getLesEnrg().size()==0){
                unePos.getLesEnrg().get(0).supprimer(numEmplacement);
                requete = "DELETE FROM emplacement WHERE numallee = ? and numquai = ? and numemplacement = ?";
                PreparedStatement prepare = laConnexion.prepareStatement(requete);
                prepare.setString(1,numAllee);
                prepare.setString(2, numQuai);
                prepare.setString(3, numEmplacement);
                prepare.executeUpdate();
                prepare.close();
            } else {
                JOptionPane.showMessageDialog(null, "Suppresion non effectué :"
                    + " les positions sont occupées", "PROBLEME", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Suppresion non effecuté :"
                + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }

    public String getNumAllee() {
        return numAllee;
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }

    public String getNumQuai() {
        return numQuai;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }
}
