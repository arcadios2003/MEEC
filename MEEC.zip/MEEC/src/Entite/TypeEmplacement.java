/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author arthu
 */
public class TypeEmplacement {
    String typeCont;
    String numAllee;
    String numQuai;
    String numEmplacement;
    private final ArrayList<TypeEmplacement> lesEnrg = new ArrayList<>();
    
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();
    
    public TypeEmplacement (String typeCont,String numAllee,String numQuai,String numEmplacement){
        this.typeCont = typeCont;
        this.numAllee = numAllee;
        this.numQuai = numQuai;
        this.numEmplacement = numEmplacement;
    }
    
    public TypeEmplacement (){
        lireRecup();
    }
    
    public ArrayList<TypeEmplacement> getLesEnrg() {
        return lesEnrg;
    }
    
    private void lireRecup(){
        String rqSQL = "SELECT * FROM typeEmplacement";
        lesEnrg.retainAll(lesEnrg);
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()) {
                String unQuai = rs.getString("quai");
                String uneAllee = rs.getString("allee");
                String unEmplacement = rs.getString("emplacement");
                String unTypeConteneur = rs.getString("typeConteneur");
                lesEnrg.add(new TypeEmplacement(unQuai,uneAllee,unEmplacement,unTypeConteneur));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Quai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void creer(String quai, String allee, String emplacement, String typeCont){     
        try { 
           String requete = null;
            requete="INSERT INTO typeEmplacement VALUES (?,?,?,?)";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            prepare.setString(1,quai);
            prepare.setString(2,allee);
            prepare.setString(3,emplacement);
            prepare.setString(4,typeCont);
            prepare.execute();
            prepare.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Ajout non effectuée: " + ex.getMessage(),"PROBLEME",JOptionPane.ERROR_MESSAGE);
        }      
    }

    public String getTypeCont() {
        return typeCont;
    }

    public void setTypeCont(String typeCont) {
        this.typeCont = typeCont;
    }

    public String getNumAllee() {
        return numAllee;
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }

    public String getNumQuai() {
        return numQuai;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }

    public String getNumEmplacement() {
        return numEmplacement;
    }

    public void setNumEmplacement(String numEmplacement) {
        this.numEmplacement = numEmplacement;
    }
}
