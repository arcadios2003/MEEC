/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import java.util.ArrayList;
import java.sql.Connection;
import Controle.Connexion.ControleConnexion;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author a.catty
 */
public class Allee {
    String numAllee;
    String numQuai;
    private final ArrayList<Allee> lesEnrg = new ArrayList<>();

    public ArrayList<Allee> getLesEnrg() {
        return lesEnrg;
    }
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();

    public Allee(String numAllee, String numQuai){
        this.numAllee = numAllee;
        this.numQuai = numQuai;
    }
    
    public Allee(){
        lireRecup("");
    }
    
    public Allee(String quai){
        lireRecup(quai);
    }
    public String getNumAllee() {
        return numAllee;
    }
    
    public void lireRecup(String quai) {
        if(quai.equals("")){
            quai="%";
        }
        String rqSQL="SELECT * FROM allee WHERE numQuai LIKE '" + quai + "' order by numQuai, numAllee";
        lesEnrg.retainAll(lesEnrg);
        
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()){
                String unIdquai = rs.getString("numquai");
                String unIdAllee = rs.getString("numallee");
                lesEnrg.add(new Allee(unIdAllee, unIdquai));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erreur" 
             + ex.getMessage(),"ALERTE",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void creer (String numAllee, String numQuai){
        boolean ok = true;
        if (!lesEnrg.isEmpty()){
            ok = false;
            int i;
            i = -1;
            do {
                i++;
            } while (!lesEnrg.get(i).numQuai.equals(numQuai)&& !lesEnrg.get(i).numAllee.equals(numAllee)&& i<lesEnrg.size());
            if(lesEnrg.get(i).numQuai.equals(numQuai)&&lesEnrg.get(i).numAllee.equals(numAllee)){
                JOptionPane.showMessageDialog(null, "Ajout non effectué :"
                    + "l'allée existe déjà!", "PROBLEME", JOptionPane.ERROR_MESSAGE);
            } else {
                ok = true;
            }
        }
        if(ok){
            String requete = null;
            try{
                requete = "INSERT INTO allee VALUE (?,?)";
                PreparedStatement prepare;
                prepare = laConnexion.prepareStatement(requete);
                prepare.setString(1,numAllee);
                prepare.setString(2,numQuai);
                prepare.execute();
                prepare.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                        + ex.getMessage(),"Probleme",JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void supprimer (String numAllee, String numQuai){
        Emplacement unEmplacement = new Emplacement(numAllee,numQuai);
        if(unEmplacement.getLesEnrg().isEmpty()){
            try {
                String requete = null;
                requete = "DELETE FROM allee WHERE numallee= ? and numquai= ?";
                PreparedStatement prepare = laConnexion.prepareStatement(requete);
                prepare.setString(1, numAllee);
                prepare.setString(2, numQuai);
                prepare.executeUpdate();
                prepare.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Suppresion non effectuée :"
                        + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Suppression non effectuée :"
                    + " l'allée contient des emplacements", "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }

    public String getNumQuai() {
        return numQuai;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }
    
    
}
