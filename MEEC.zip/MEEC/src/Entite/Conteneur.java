/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author a.catty
 */
public class Conteneur {
    String IdConteneur;
    String Loueur;
    Integer Louer;
    String quai;
    String allee;
    Integer Etage;
    String emplacement;
    Integer TypeTailleConteneur;

    private final ArrayList<Conteneur> lesEnrg = new ArrayList<>();
    
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();
    
    public Conteneur (){
        lireRecup("","");
    }
    
    public Conteneur (String Id){
        lireRecup(Id,"");
    }
    
    public Conteneur(String Id, Integer TTC){
        this.IdConteneur = Id;
        this.TypeTailleConteneur = TTC;
    }
    
    public Conteneur (String Id, int Type, int Taille) {
        this.IdConteneur = Id;
        this.TypeTailleConteneur = (Type * 10) + Taille;
    }
    
    public Conteneur (String Id,Integer TTC, String Loueur, Integer Louer, String Quai, String Allee, String Emplacement, Integer Etage){
        this.IdConteneur = Id;
        this.TypeTailleConteneur = TTC;
        this.Loueur = Loueur;
        this.Louer = Louer;
        this.quai = Quai;
        this.allee = Allee;
        this.emplacement = Emplacement;
        this.Etage = Etage;
    }

    // Code Test : CSQU3054383
    public void cree(Conteneur cont, int etage, Emplacement emplacement){
        if (cont != null){
            if (verifCode(cont.IdConteneur)) {
                String requete = null;
                try {
                    requete = "INSERT INTO conteneur (IdConteneur, TypeTailleConteneur,numQuai,numAllee,numEmplacement,Etage) VALUES (?,?,?,?,?,?)";
                    PreparedStatement prepare;
                    prepare = laConnexion.prepareStatement(requete);
                    prepare.setString(1,cont.IdConteneur);
                    prepare.setString(2, cont.TypeTailleConteneur.toString());
                    prepare.setString(3,emplacement.getNumQuai());
                    prepare.setString(4,emplacement.getNumAllee());
                    prepare.setString(5,emplacement.getNumEmplacement());
                    prepare.setString(6,Integer.toString(etage));
                    prepare.execute();
                    prepare.close();
                    setPlace(cont,etage,emplacement);
                } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                                + ex.getMessage(),"Probleme",JOptionPane.ERROR_MESSAGE);
                }
                requete = null;
                try {
                    requete = "UPDATE position SET numConteneur = ? WHERE numQuai = ? AND numAllee = ? AND numEmplacement = ? AND etage = ?";
                    PreparedStatement prepare;
                    prepare = laConnexion.prepareStatement(requete);
                    prepare.setString(1,cont.IdConteneur);
                    prepare.setString(2,emplacement.getNumQuai());
                    prepare.setString(3,emplacement.getNumAllee());
                    prepare.setString(4,emplacement.getNumEmplacement());
                    prepare.setString(5,Integer.toString(etage));
                    prepare.execute();
                    prepare.close();
                } catch (SQLException ex){
                    JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                                + ex.getMessage(),"Probleme",JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null,"Ajout non effectuée, le Matricule du contener ne correspond pas a la norme", "Pproblem", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null,"Tout les champs doivent être remplis", "Probleme", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, "L'enregistrement à bien été effectuer");
    }
    
    public void setPlace (Conteneur cont, int unEtage, Emplacement unEmplacement){
        if (unEtage != 0 && unEmplacement != null){
            if (cont != null){
                String requete = null;
                try {
                    requete = "INSERT INTO position (numPosition,numQuai,numAllee,numEmplacement,etage,numConteneur) VALUES (?,?,?,?,?,?)";
                    PreparedStatement prepare;
                    prepare = laConnexion.prepareStatement(requete);
                    prepare.setString(1, unEmplacement.numEmplacement + unEmplacement.numAllee + unEmplacement.numQuai + Integer.toString(unEtage));
                    prepare.setString(2, unEmplacement.numQuai);
                    prepare.setString(3, unEmplacement.numAllee);
                    prepare.setString(4, unEmplacement.numEmplacement);
                    prepare.setString(5, Integer.toString(unEtage));
                    prepare.setString(6, cont.IdConteneur.toUpperCase());
                    prepare.execute();
                    prepare.close();
                } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                                + ex.getMessage(),"Probleme",JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    @SuppressWarnings("empty-statement")
    public boolean verifCode(String Id){
        Id = Id.toUpperCase();
        char [] listeLettre = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        int [] equivalentChiffre = {10,12,13,14,15,16,17,18,19,20,21,23,24,25,26,27,28,29,30,31,32,34,35,36,37,38};
        int somme = 0;
        
        for(int i = 0; i < 4; i++){
            for (int x = 0; x < 26; x++){
                if (listeLettre[x] == Id.charAt(i)){
                    somme = somme + (int) equivalentChiffre[x] * (int) Math.pow(2,i);
                }
            }
        }
        
        if (Id.length() == 12){
            for (int i = 5; i < 10; i++){
                somme = somme + (int)Id.charAt(i) * (int) Math.pow(2, i);
            }   
        } else {
            for (int i = 4; i < 10; i++){
                Integer multiple1 = Integer.parseInt(Id.charAt(i)+"");
                Integer multiple2 = (int)Math.pow(2, i);
                Integer carre =  multiple1 * multiple2 ;
                somme = somme + carre;
            }
        }
        
        int mod = (somme/11)*11;
        
        if (Id.length() == 12){
            if(somme - mod == Integer.parseInt(Id.charAt(11)+"")){
                return true;
            } else {
                return false;
            }
        } else {
            if(somme - mod == Integer.parseInt(Id.charAt(10)+"")){
                return true;
            } else {
                return false;
            }
        }        
    }
    
    public ArrayList<Conteneur> getLesEnrg() {
        return lesEnrg;
    }
    
    private void lireRecup(String Id, String Cli){
        String rqSQL = "SELECT * FROM conteneur WHERE IdConteneur LIKE '"+Id+"%'";
        String finrqSQL = null;
        if (Cli == "") {
            finrqSQL = ";";
        } else {
            finrqSQL = " AND loueur = '"+Cli+"';";
        }
        lesEnrg.retainAll(lesEnrg);
        
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()) {
                String IdCont= rs.getString("IdConteneur");
                Integer TTC = Integer.valueOf(rs.getString("TypeTailleConteneur"));
                String Temp_Quai = rs.getString("numQuai");
                String Temp_Allee = rs.getString("numAllee");
                String Temp_Emplacement = rs.getString("numEmplacement");
                Integer Temp_Louer = Integer.valueOf(rs.getString("louer"));
                String Temp_Loueur = rs.getString("loueur");
                Integer Temp_Etage = Integer.valueOf(rs.getString("Etage"));
                lesEnrg.add(new Conteneur(IdCont,TTC,Temp_Loueur,Temp_Louer,Temp_Quai, Temp_Allee, Temp_Emplacement,Temp_Etage));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Quai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getIdConteneur() {
        return IdConteneur;
    }

    public String getLoueur() {
        return Loueur;
    }

    public void setLoueur(String Loueur) {
        this.Loueur = Loueur;
    }
    
    public Integer getLouer() {
        return Louer;
    }

    public void setLouer(Integer Louer) {
        this.Louer = Louer;
    }

    public void setIdConteneur(String IdConteneur) {
        this.IdConteneur = IdConteneur;
    }

    public Integer getTypeTailleConteneur() {
        return TypeTailleConteneur;
    }

    public void setTypeTailleConteneur(Integer TypeTailleConteneur) {
        this.TypeTailleConteneur = TypeTailleConteneur;
    }

    public String getQuai() {
        return quai;
    }

    public void setQuai(String quai) {
        this.quai = quai;
    }

    public String getAllee() {
        return allee;
    }

    public void setAllee(String allee) {
        this.allee = allee;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public Integer getEtage() {
        return Etage;
    }

    public void setEtage(Integer Etage) {
        this.Etage = Etage;
    }
    
}