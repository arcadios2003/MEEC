/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author a.catty
 */
public class TypeCont {
    String numType;
    String nomType;
    private final ArrayList<TypeCont> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();
    
    public TypeCont(String numType, String nomType){
        this.numType=numType;
        this.nomType=nomType;
    }
    
    public TypeCont(){
        lireRecup("");
    }
    
    public TypeCont(String nomType) {
        this.nomType = nomType;
        lireRecup(nomType);
    }
    
    public ArrayList<TypeCont> getLesEnrg() {
        return lesEnrg;
    }
    
    private void lireRecup(String nomType){
        String rqSQL = null;
        
        if (nomType.equals("")){
            rqSQL = "SELECT * FROM typeConteneur";
        } else {
            rqSQL = "SELECT * FROM typeConteneur WHERE typeLibel =" + nomType;
        }
        lesEnrg.retainAll(lesEnrg);
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()) {
                String unId= rs.getString("typeCode");
                String unNom = rs.getString("typeLibel");
                lesEnrg.add(new TypeCont(unId, unNom));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Quai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getNumType() {
        return numType;
    }

    public void setNumType(String numType) {
        this.numType = numType;
    }

    public String getNomType() {
        return nomType;
    }

    public void setNomType(String nomType) {
        this.nomType = nomType;
    }
    
    
}
