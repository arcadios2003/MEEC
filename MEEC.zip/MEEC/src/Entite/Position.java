/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author a.catty
 */
public class Position {
    String numPosition;
    String numEmplacement;
    String numAllee;
    String numQuai;
    String numConteneur;
    String Etage;
    private final ArrayList<Position> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();

    public String getNumPosition() {
        return numPosition;
    }

    public void setNumPosition(String numPosition) {
        this.numPosition = numPosition;
    }

    public String getNumEmplacement() {
        return numEmplacement;
    }

    public void setNumEmplacement(String numEmplacement) {
        this.numEmplacement = numEmplacement;
    }

    public String getNumAllee() {
        return numAllee;
    }

    public void setNumAllee(String numAllee) {
        this.numAllee = numAllee;
    }
    
    public String getNumQuai() {
        return numQuai;
    }

    public void setNumQuai(String numQuai) {
        this.numQuai = numQuai;
    }

    public String getNumConteneur() {
        return numConteneur;
    }

    public void setNumConteneur(String numConteneur) {
        this.numConteneur = numConteneur;
    }

    public String getEtage() {
        return Etage;
    }

    public void setEtage(String Etage) {
        this.Etage = Etage;
    }
    
    public ArrayList<Position> getLesEnrg() {
        return lesEnrg;
    }
    
    public Position (String numPosition, String numEmplacement, String numAllee, String numQuai,String Etage, String numConteneur){
        this.numPosition = numPosition;
        this.numEmplacement = numEmplacement;
        this.numAllee = numAllee;
        this.numQuai = numQuai;
        this.Etage = Etage;
        this.numConteneur = numConteneur;
    }
    
    public Position(){
        
    }
    
    public Position(String numEmplacement, String numAllee, String numQuai, boolean vide){
        lireRecup("",numEmplacement, numAllee, numQuai,"","",vide);
    }
    
    public Position (String numEmplacement, String numAllee, String numQuai){
        lireRecup("",numEmplacement, numAllee, numQuai, "","", false);
    }
    
    public Position (String numEmplacement, String numAllee, String numQuai, String Etage, boolean vide){
        lireRecup("", numEmplacement, numAllee, numQuai, Etage, "", vide);
    }
    
    public Position (String numCont, boolean vide) {
        lireRecup("","","","","",numCont, vide);
    }
    
    public void supprimer (String numPos){
        String requete = null;
         try {
            requete = "DELETE FROM position WHERE numposition=?";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            prepare.setString(1, numPos);
            prepare.executeUpdate();
            prepare.close();
        } catch (SQLException ex) {        
            JOptionPane.showMessageDialog(null, "Suppresion non effectuée :"
                + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void creer (String numEmplacement, String numAllee, String numQuai, String Etage){
        String requete = null;
        String pos;

        try{
            requete="INSERT INTO position VALUES (?,?,?,?,?,null)";
            PreparedStatement prepare;
            prepare = laConnexion.prepareStatement(requete);
            pos = numEmplacement + numAllee + numQuai + Etage;
            prepare.setString(1,pos);
            prepare.setString(2, numQuai);
            prepare.setString(3, numAllee);
            prepare.setString(4, numEmplacement);
            prepare.setString(5, Etage);
            prepare.execute();
            prepare.close();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ajout non effectuée :"
                + ex.getMessage(), "PROBLEME", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void miseAJour (String numPosition, String numConteneur){
        String requete = null;
        try {
            requete = "UPDATE position SET numConteneur = ? WHERE numPosition = ?";
            PreparedStatement prepare = laConnexion.prepareStatement(requete);;
            
            if(numConteneur.equals("")){
                prepare.setNull(1, 0);
            } else {
               prepare.setString(1, numConteneur); 
            }
            prepare.setString(2, numPosition);
            prepare.executeUpdate();
            prepare.close();
        } catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Suppresion non effecuté :" + ex.getMessage(),"PROBLEME",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void lireRecup(String numPosition, String numEmplacement, String numAllee, String numQuai, String Etage, String numCont, boolean vide){
        if(numPosition.equals("")){
            numPosition ="%";
        }
        
        if(numEmplacement.equals("")){
            numEmplacement ="%";
        }
        
        if(numAllee.equals("")){
            numAllee ="%";
        }
        
        if(numQuai.equals("")){
            numQuai ="%";
        }
        
        if(!Etage.equals("")){
            Etage = " and etage LIKE '" + Etage + "' ";
        }
        
        if(numCont.equals("")){
            numCont = "%";
        }
        
        String rqfin = " and numconteneur is not null";
        if(vide){
            rqfin = "and numconteneur is null";
        }
        
        String rqSQL = "SELECT * FROM position WHERE numposition LIKE '" + numPosition + "' and numemplacement LIKE '" + numEmplacement + "' and numAllee LIKE '" + numAllee + "' and numquai LIKE '" + numQuai + "' " + rqfin + " order by numquai, numallee, numemplacement, etage";
        lesEnrg.retainAll(lesEnrg);
        
        try{
            Statement state = laConnexion.createStatement();
            
            ResultSet rs = state.executeQuery(rqSQL);
            while(rs.next()){
               String unIdQuai = rs.getString("numquai");
               String unIdAllee = rs.getString("numallee");
               String unEmplacement = rs.getString("numemplacement");
               String unEtage = rs.getString("etage");
               String unNumCont = rs.getString("numConteneur");
               String uneIdPosition = rs.getString(("numposition"));
               lesEnrg.add(new Position(uneIdPosition,unEmplacement, unIdAllee, unIdQuai, unEtage, unNumCont));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(Position.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}