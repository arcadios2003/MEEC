/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entite;

import Controle.Connexion.ControleConnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author a.catty
 */
public class TailCont {
    String numTail;
    String Long;
    String Larg;
    String Haut;
    String Complet;
    private final ArrayList<TailCont> lesEnrg = new ArrayList<>();
    private static Connection laConnexion = ControleConnexion.getLaConnectionStatique();
    
    public TailCont(String numTail, String Long, String Larg, String Haut){
        this.numTail=numTail;
        this.Long = Long;
        this.Larg = Larg;
        this.Haut = Haut;
        this.Complet=Long + " / " + Larg + " / " + Haut;
    }
    
    public TailCont(){
        lireRecup();
    }
    
    public ArrayList<TailCont> getLesEnrg() {
        return lesEnrg;
    }
    
    private void lireRecup(){
        String rqSQL = "SELECT * FROM tailleconteneur";
        lesEnrg.retainAll(lesEnrg);
        try{
            Statement state = laConnexion.createStatement();
            ResultSet rs=state.executeQuery(rqSQL);
            while(rs.next()) {
                String unId= rs.getString("taillecode");
                String uneLong = rs.getString("taillLong");
                String uneLarg = rs.getString("taillLarg");
                String uneHaut = rs.getString("taillHaut");
                lesEnrg.add(new TailCont(unId, uneLong,uneLarg,uneHaut));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Quai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String getNumTail() {
        return numTail;
    }

    public void setNumTail(String numTail) {
        this.numTail = numTail;
    }

    public String getLong() {
        return Long;
    }

    public void setLong(String Long) {
        this.Long = Long;
    }

    public String getLarg() {
        return Larg;
    }

    public void setLarg(String Larg) {
        this.Larg = Larg;
    }

    public String getHaut() {
        return Haut;
    }

    public void setHaut(String Haut) {
        this.Haut = Haut;
    }

    public String getComplet() {
        return Complet;
    }

    public void setComplet(String Complet) {
        this.Complet = Complet;
    }
    
    
}
